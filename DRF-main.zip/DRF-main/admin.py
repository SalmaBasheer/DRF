from django.contrib import admin
from accounts.models import user,Blogpost

# Register your models here.
admin.site.register(user)
admin.site.register(Blogpost)

